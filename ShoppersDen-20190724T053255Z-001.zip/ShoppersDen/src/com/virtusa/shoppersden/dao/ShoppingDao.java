package com.virtusa.shoppersden.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CardDetails;
import com.virtusa.shoppersden.model.CategoryDetails;
import com.virtusa.shoppersden.model.CustomerDetails;
import com.virtusa.shoppersden.model.LoginDetails;
import com.virtusa.shoppersden.model.OrderDetails;
import com.virtusa.shoppersden.model.ProductDetails;
import com.virtusa.shoppersden.util.ConnectionUtil;

public class ShoppingDao {
	
	private int customerNo;

	public int doRegister(CustomerDetails customer) throws ShoppingException {
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt = null;
		ResultSet resultSet = null;
		try {
			psmt = con.prepareStatement(
					"insert into customermaster(customerName,customerEmail,customerPassword,customerAddress,customerDob,customerContact,customerCity,customerState) "
							+ "values(?,?,?,?,?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);
			psmt.setString(1, customer.getCustomerName());
			psmt.setString(2, customer.getCustomerEmail());
			psmt.setString(3, customer.getCustomerPassword());
			psmt.setString(4, customer.getCustomerAddress());
			psmt.setString(5, customer.getDOB());
			psmt.setLong(6, customer.getCustomerContact());
			psmt.setString(7, customer.getCustomerCity());
			psmt.setString(8, customer.getCustomerState());
			psmt.executeUpdate();
			resultSet = psmt.getGeneratedKeys();
			if (resultSet.next()) {
				customerNo = resultSet.getInt(1);
				System.out.println(customerNo);
			}
		} catch (SQLException e) {
			throw new ShoppingException(e.getMessage());
		} catch (Exception e) {
			throw new ShoppingException(e.getMessage());
		}
		finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (psmt != null) {
					psmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				throw new ShoppingException(" error while closing a resource contact to admin");
			} catch (Exception e) {
				throw new ShoppingException("  contact to admin");
			}
		}
		return customerNo;
	}

	public CustomerDetails doLogin(LoginDetails login) throws ShoppingException {
		String email = login.getUsername();
		String password = login.getPassword();
		CustomerDetails customer = null;
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt = null;
		ResultSet resultSet = null;
		try {
			psmt = con.prepareStatement(
					"select customerId,customerName from customermaster where customerEmail=? and customerPassword=?");
			psmt.setString(1, email);
			psmt.setString(2, password);
			resultSet = psmt.executeQuery();
			if (resultSet.next()) {
				customer = new CustomerDetails(resultSet.getInt(1), resultSet.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customer;
	}

	public List<ProductDetails> doSearch(String searchItem) throws ShoppingException {
		Connection con = ConnectionUtil.getConnection();
		System.out.println(searchItem);
		List<ProductDetails> list=new ArrayList<ProductDetails>();
		PreparedStatement psmt = null;
		ResultSet resultSet = null;
		try {
			psmt = con.prepareStatement("Select * from ProductDetails where productName=?");
			psmt.setString(1, searchItem);
			resultSet = psmt.executeQuery();
			while (resultSet.next()) {
				CategoryDetails category = new CategoryDetails(resultSet.getInt(6));
				int productId = resultSet.getInt(1);
				String productImage = resultSet.getString(2);
				String productName = resultSet.getString(3);
				float productPrice = resultSet.getFloat(4);
				int productStock = resultSet.getInt(5);
				String productDescription = resultSet.getString(7);
				ProductDetails product = new ProductDetails(productId, productImage, productName, productPrice, productStock, category,
						productDescription);
				System.out.println(product);	
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public int doOrder(OrderDetails details) throws ShoppingException {
		Connection con = ConnectionUtil.getConnection();
		int id = 0;
		PreparedStatement psmt = null;
		ResultSet resultSet = null;
		try {
			System.out.println("DAO ENTERED");
			psmt = con.prepareStatement(
					"insert into orderDetails(orderCustomerFk,orderProductFk,ordertQuantity,OrderStatus,orderTotalAmount) "
							+ "values(?,?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);
			psmt.setInt(1, details.getCustomerId());
			psmt.setInt(2, details.getProductId());
			psmt.setInt(3, details.getOrderQuantity());
			psmt.setInt(4, 1);
			psmt.setFloat(5, details.getOrderTotalAmount());
			psmt.executeUpdate();
			resultSet = psmt.getGeneratedKeys();
			if (resultSet.next()) {

				id = resultSet.getInt(1);
			}

		} catch (SQLException e) {
			throw new ShoppingException(e.getMessage());
		} catch (Exception e) {
			throw new ShoppingException(e.getMessage());
		}
		finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (psmt != null) {
					psmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

				// TODO: handle exception
				throw new ShoppingException(" error while closing a resource contact to admin");

			} catch (Exception e) {
				// TODO: handle exception
				throw new ShoppingException("  contact to admin");
			}
		}
		return id;
	}

	public int doPayment(CardDetails details) throws ShoppingException {
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt = null;
		int id=0;
		ResultSet resultSet = null;
		try {
			System.out.println("DAO ENTERED");
			psmt = con.prepareStatement(
					"insert into cardDetails(cardNumber,cardHolderName,cardType,cardExpiryDate,cardCVV) "
							+ "values(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
			psmt.setLong(1, details.getCardNumber());
			psmt.setString(2, details.getCardName());
			psmt.setString(3, details.getCardType());
			psmt.setString(4, details.getExpiryDate());
			psmt.setLong(5, details.getCVV());
			psmt.executeUpdate();
			resultSet = psmt.getGeneratedKeys();
			if (resultSet.next()) {
			 id=resultSet.getInt(1)	;
			}
		} catch (SQLException e) {
			throw new ShoppingException(e.getMessage());
		} catch (Exception e) {
			throw new ShoppingException(e.getMessage());
		}

		finally {
			try {

				if (resultSet != null) {
					resultSet.close();
				}
				if (psmt != null) {
					psmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

				// TODO: handle exception
				throw new ShoppingException(" error while closing a resource contact to admin");

			} catch (Exception e) {
				// TODO: handle exception
				throw new ShoppingException("  contact to admin");
			}
		}
		return id;
	}

}
