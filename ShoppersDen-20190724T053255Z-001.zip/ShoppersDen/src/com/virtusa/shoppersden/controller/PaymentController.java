package com.virtusa.shoppersden.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CardDetails;
import com.virtusa.shoppersden.service.ShoppingService;

/**
 * Servlet implementation class PaymentController
 */
@WebServlet("/PaymentController")
public class PaymentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cardNo = request.getParameter("cardNumber");
		String cardName = request.getParameter("cardHolderName");
		String cardType = request.getParameter("cardType");
		String cardExpiryDate = request.getParameter("Edate");
		String cvv = request.getParameter("cvv");
		long cardNumber = Long.parseLong(cardNo);
		long cvvNumber=Long.parseLong(cvv);
		CardDetails details=new CardDetails(cardNumber,cardName,cardType,cardExpiryDate,cvvNumber);
		ShoppingService service=new ShoppingService();
		try {
			int id=service.doPayment(details);
			if(id!=0) {
				RequestDispatcher dispatcher=request.getRequestDispatcher("/Jsp/BillingPage.jsp");
				dispatcher.forward(request, response);
			}
		} catch (ShoppingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
