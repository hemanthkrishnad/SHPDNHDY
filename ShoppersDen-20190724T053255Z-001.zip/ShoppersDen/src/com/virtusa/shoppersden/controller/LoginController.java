package com.virtusa.shoppersden.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CustomerDetails;
import com.virtusa.shoppersden.model.LoginDetails;
import com.virtusa.shoppersden.service.ShoppingService;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		LoginDetails login = new LoginDetails(username, password);
		ShoppingService service = new ShoppingService();
		if ((username.equalsIgnoreCase("admin@gmail.com")) && (password.equals("admin"))) {
			session.setAttribute("name", "Admin");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/Admin.jsp");
			dispatcher.forward(request, response);
		} else {
			try {
				CustomerDetails customer = service.doLogin(login);
				if (customer == null) {
					RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/Error.jsp");
					dispatcher.forward(request, response);
				} else if (customer != null) {
					request.setAttribute("username", customer);
					session.setAttribute("name", customer.getCustomerName());
					session.setAttribute("cid", customer.getCustomerId());
					RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/HomePage.jsp");
					dispatcher.forward(request, response);
				}
			} catch (ShoppingException e) {
				e.printStackTrace();
			}
		}

	}
}
