package com.virtusa.shoppersden.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.shoppersden.model.ProductDetails;
import com.virtusa.shoppersden.service.ShoppingService;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/SearchController")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String searchItem = request.getParameter("searchText");
		List<ProductDetails> list=new ArrayList<ProductDetails>();
		ShoppingService service;
		try {
			service = new ShoppingService();
			list = service.doSearch(searchItem);
			if (list != null) {
				request.setAttribute("list", list);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/HomePage.jsp");
				dispatcher.forward(request, response);
				//response.sendRedirect("/ShoppersDen/Jsp/Login.jsp");
			}
			else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/Error.jsp");
				dispatcher.include(request, response);
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
