package com.virtusa.shoppersden.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.OrderDetails;
import com.virtusa.shoppersden.service.ShoppingService;


/**
 * Servlet implementation class BuyNowController
 */
@WebServlet("/BuyNowController")
public class BuyNowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String quantity=request.getParameter("orderQuantity");
		System.out.println(quantity);
		float price=(float) session.getAttribute("productPrice");
		int productId=(int) session.getAttribute("productId");
		System.out.println(quantity);
		int orderQuantity=Integer.parseInt(quantity);
		float totalPrice=orderQuantity*price;
		int customerId=(int)session.getAttribute("cid");
		ShoppingService service=new ShoppingService();
		OrderDetails details=new OrderDetails(customerId,productId,orderQuantity,totalPrice);
		try {
			int id=service.doOrder(details);
			System.out.println(totalPrice);
			session.setAttribute("orderQuantity",orderQuantity);
			session.setAttribute("totalAmount",totalPrice);
			RequestDispatcher dispatcher=request.getRequestDispatcher("/Jsp/Payment.jsp");
			dispatcher.forward(request, response);
		} catch (ShoppingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
