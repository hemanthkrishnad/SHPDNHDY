package com.virtusa.shoppersden.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CustomerDetails;
import com.virtusa.shoppersden.service.ShoppingService;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationController() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String customerName = request.getParameter("name");
		String customerEmail = request.getParameter("email");
		String customerPassword = request.getParameter("password");
		String dob = request.getParameter("dob");
		String contact = request.getParameter("contact");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		String customerAddress = request.getParameter("address");
		long customerContact = Long.parseLong(contact);
		CustomerDetails customerDetails = new CustomerDetails(customerName, customerEmail, customerPassword, dob,
				customerContact, state, city, customerAddress);
		ShoppingService service = new ShoppingService();
		try {
			int id = service.doRegister(customerDetails);
			if (id != 0) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/HomePage.jsp");
				dispatcher.forward(request, response);
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/Jsp/Error.jsp");
				dispatcher.forward(request, response);
			}
		} catch (ShoppingException e) {
			e.printStackTrace();
		}
	}
}
