package com.virtusa.shoppersden.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.virtusa.shoppersden.exception.ShoppingException;

public class ConnectionUtil {
static Connection con;
	
	public static Connection getConnection() throws ShoppingException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new ShoppingException("Driver is not available ");	
		}
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost/shoppersden","root","manager");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ShoppingException("Connection is not available ");		
		}
		return con;
	}
}
