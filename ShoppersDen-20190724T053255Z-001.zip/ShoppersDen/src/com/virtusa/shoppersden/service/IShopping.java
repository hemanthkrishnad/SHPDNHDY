package com.virtusa.shoppersden.service;

import java.util.List;

import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CardDetails;
import com.virtusa.shoppersden.model.CustomerDetails;
import com.virtusa.shoppersden.model.LoginDetails;
import com.virtusa.shoppersden.model.OrderDetails;
import com.virtusa.shoppersden.model.ProductDetails;

public interface IShopping {
	public int doRegister(CustomerDetails customer) throws ShoppingException;
	public CustomerDetails doLogin(LoginDetails login) throws ShoppingException;
	public List<ProductDetails> doSearch(String searchItem) throws ShoppingException;
	public int doOrder(OrderDetails details) throws ShoppingException;
	public int doPayment(CardDetails details) throws ShoppingException;
}
