package com.virtusa.shoppersden.service;

import java.util.List;

import com.virtusa.shoppersden.dao.ShoppingDao;
import com.virtusa.shoppersden.exception.ShoppingException;
import com.virtusa.shoppersden.model.CardDetails;
import com.virtusa.shoppersden.model.CustomerDetails;
import com.virtusa.shoppersden.model.LoginDetails;
import com.virtusa.shoppersden.model.OrderDetails;
import com.virtusa.shoppersden.model.ProductDetails;

public class ShoppingService implements IShopping {
	private ShoppingDao dao=new ShoppingDao();

	@Override
	public int doRegister(CustomerDetails customer) throws ShoppingException {
		return dao.doRegister(customer);
	}

	@Override
	public CustomerDetails doLogin(LoginDetails login) throws ShoppingException {
		return dao.doLogin(login);
	}

	@Override
	public List<ProductDetails> doSearch(String searchItem) throws ShoppingException {
		return dao.doSearch(searchItem);
	}

	@Override
	public int doOrder(OrderDetails details) throws ShoppingException {
		return dao.doOrder(details);
	}

	@Override
	public int doPayment(CardDetails details) throws ShoppingException {
		return dao.doPayment(details);
	}

	
}
