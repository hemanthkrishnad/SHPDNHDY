package com.virtusa.shoppersden.model;

public class CardDetails {
	private long cardNumber;
	private String cardName;
	private String cardType;
	private String ExpiryDate;
	private long CVV;
	public long getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getExpiryDate() {
		return ExpiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		ExpiryDate = expiryDate;
	}
	public long getCVV() {
		return CVV;
	}
	public void setCVV(long cVV) {
		CVV = cVV;
	}
	@Override
	public String toString() {
		return "CardDetails [cardNumber=" + cardNumber + ", cardName=" + cardName + ", cardType=" + cardType
				+ ", ExpiryDate=" + ExpiryDate + ", CVV=" + CVV + "]";
	}
	public CardDetails(long cardNumber, String cardName, String cardType, String expiryDate, long cVV) {
		super();
		this.cardNumber = cardNumber;
		this.cardName = cardName;
		this.cardType = cardType;
		ExpiryDate = expiryDate;
		CVV = cVV;
	}
}
