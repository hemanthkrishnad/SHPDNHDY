package com.virtusa.shoppersden.model;

import java.util.Date;


public class ShoppingCart {
	private int cartId;
	private ProductDetails product;
	private CustomerDetails customer;
	@Override
	public String toString() {
		return "ShoppingCart [cartId=" + cartId + ", product=" + product + ", customer=" + customer
				+ "]";
	}
	public ShoppingCart(int cartId, ProductDetails product, Date date, CustomerDetails customer) {
		super();
		this.cartId = cartId;
		this.product = product;
		this.customer = customer;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public ProductDetails getProduct() {
		return product;
	}
	public void setProduct(ProductDetails product) {
		this.product = product;
	}
	public CustomerDetails getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDetails customer) {
		this.customer = customer;
	}
}
