package com.virtusa.shoppersden.model;

public class CustomerDetails {
	private int customerId;
	private String customerName;
	private String customerEmail;
	private String customerPassword;
	private String DOB;
	private String customerAddress;
	private long customerContact;
	private String customerState;
	private String customerCity;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public long getCustomerContact() {
		return customerContact;
	}
	public void setCustomerContact(long customerContact) {
		this.customerContact = customerContact;
	}
	public String getCustomerState() {
		return customerState;
	}
	public void setCustomerState(String customerState) {
		this.customerState = customerState;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	@Override
	public String toString() {
		return "CustomerDetails [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerPassword=" + customerPassword + ", DOB=" + DOB + ", customerAddress="
				+ customerAddress + ", customerContact=" + customerContact + ", customerState=" + customerState
				+ ", customerCity=" + customerCity + "]";
	}
	public CustomerDetails(String customerName, String customerEmail, String customerPassword, String customerDob,
			long customerContact,String customerState,String customerCity,String customerAddress) {
		super();
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
		DOB = customerDob;
		this.customerAddress = customerAddress;
		this.customerContact = customerContact;
		this.customerState = customerState;
		this.customerCity = customerCity;
	}
	public CustomerDetails(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;		
	}
}
