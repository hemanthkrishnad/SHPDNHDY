package com.virtusa.shoppersden.model;

import java.util.Date;
public class TransactionDetails {
	private int transactionId;
	private OrderDetails order;
	private Date transactionDate;
	private float transactionAmount;
	private CustomerDetails customer;
	private int transactionStatus;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public OrderDetails getOrder() {
		return order;
	}
	public void setOrder(OrderDetails order) {
		this.order = order;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public float getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public CustomerDetails getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDetails customer) {
		this.customer = customer;
	}
	public int getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(int transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public TransactionDetails(int transactionId, OrderDetails order, Date transactionDate, float transactionAmount,
			CustomerDetails customer, int transactionStatus) {
		super();
		this.transactionId = transactionId;
		this.order = order;
		this.transactionDate = transactionDate;
		this.transactionAmount = transactionAmount;
		this.customer = customer;
		this.transactionStatus = transactionStatus;
	}
	@Override
	public String toString() {
		return "TransactionDetails [transactionId=" + transactionId + ", order=" + order + ", transactionDate="
				+ transactionDate + ", transactionAmount=" + transactionAmount + ", customer=" + customer
				+ ", transactionStatus=" + transactionStatus + "]";
	}
}
