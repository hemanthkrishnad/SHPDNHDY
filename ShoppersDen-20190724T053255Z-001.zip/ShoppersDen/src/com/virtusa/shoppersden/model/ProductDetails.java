package com.virtusa.shoppersden.model;

public class ProductDetails {
	private int productId;
	private String productName;
	private String productImage;
	private float productPrice;
	private String productDescription;
	private int productStock;
	private CategoryDetails category;
	
	public ProductDetails(int productId, String productImage, String productName, float productPrice, int productStock,
			CategoryDetails category, String productDescription) {
		super();
		this.productId = productId;
		this.productImage = productImage;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productStock = productStock;
		this.category = category;
		this.productDescription = productDescription;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductStock() {
		return productStock;
	}
	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}
	
	public CategoryDetails getCategory() {
		return category;
	}
	public void setCategory(CategoryDetails category) {
		this.category = category;
	}
	
	@Override
	public String toString() {
		return "ProductDetails [productId=" + productId + ", productName=" + productName + ", productImage="
				+ productImage + ", productPrice=" + productPrice + ", productDescription=" + productDescription
				+ ", productStock=" + productStock + ", category=" + category + "]";
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
}
