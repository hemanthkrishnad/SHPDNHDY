package com.virtusa.shoppersden.model;

public class OrderDetails {
	private int orderId;
	private CustomerDetails customer;
	private ProductDetails product;
	private int orderQuantity;
	private float orderTotalAmount;
	private int orderStatus;
	private int customerId;
	private int productId;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public CustomerDetails getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDetails customer) {
		this.customer = customer;
	}
	public ProductDetails getProduct() {
		return product;
	}
	public void setProduct(ProductDetails product) {
		this.product = product;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public float getOrderTotalAmount() {
		return orderTotalAmount;
	}
	public void setOrderTotalAmount(float orderTotalAmount) {
		this.orderTotalAmount = orderTotalAmount;
	}
	public int getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(int orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public OrderDetails(int orderId, CustomerDetails customer, ProductDetails product, int orderQuantity,
			float orderTotalAmount, int orderStatus) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.product = product;
		this.orderQuantity = orderQuantity;
		this.orderTotalAmount = orderTotalAmount;
		this.orderStatus = orderStatus;
		
	}
	public OrderDetails( int customerId, int productId, int orderQuantity,
			float orderTotalAmount) {
		super();
		this.customerId = customerId;
		this.productId = productId;
		this.orderQuantity = orderQuantity;
		this.orderTotalAmount = orderTotalAmount;
		
		
	}
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", customer=" + customer + ", product=" + product
				+ ", orderQuantity=" + orderQuantity + ", orderTotalAmount=" + orderTotalAmount + ", orderStatus="
				+ orderStatus +  "]";
	}
}
